import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:lionsclub/Widgets/upcomingEvent.dart';
import 'loginPage.dart';
import 'Widgets/sideBar.dart';
import 'Widgets/AdminWidget/adminReport.dart';
import 'Widgets/ActivityReporting/activityReport.dart';
import 'package:lionsclub/Widgets/profilePage.dart';
import 'Widgets/Billing/uploadBills.dart';
import 'package:share/share.dart';
import 'Widgets/Models/userModel.dart';

import 'package:http/http.dart' as http;
import 'GetDetails/GetEvents.dart';

class MyHomePage extends StatefulWidget {


  final String title;
  @override
  MyHomePage(this.title);
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey();

  List<GetEvents> _eventDetails = List<GetEvents>();

  Future<List<GetEvents>> _getUpcomingEvents() async {
    String url = "https://lions3234d2.com/api.php?category=events&view=true";
    var response = await http.get(url);
    var description = json.decode(response.body);
    List<GetEvents> events = [];

    if(response.statusCode == 200){
      for(var getEventJson in description){
        events.add(GetEvents.fromJson(getEventJson));
      }
    }
    return events;
  }

  Widget createBody() {
    return ListView(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 20,bottom: 20),
          child: Container(
            height: 200,
            child: Center(
              child: Image.asset('images/logo.png'),
              //Text("IMAGE Portion"),
            ),
          ),
        ),

        SizedBox(
          height: 20,
        ),

        Container(
            child:Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Spacer(),

                HomePageThreeInRowCards(
                  width: 120,
                    height: 110,
                    displayText: "Activity Report",
                    iconData: Icons.repeat,
                    cardOnPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ActivityReport('Activity Report')),
                      );
                    },
                    context: context
                ),

                HomePageThreeInRowCards(
                    width: 120,
                    height: 110,
                    displayText: "Admin Reporting",
                    iconData: Icons.group,
                    cardOnPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AdminReport('Admin Reports')),
                      );
                    },
                    context: context
                ),

                HomePageThreeInRowCards(
                    width: 120,
                    height: 110,
                    displayText: "Upload \nBills",
                    iconData: Icons.monetization_on,
                    cardOnPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => UploadBills('Upload Bills')),
                      );
                    },
                    context: context
                ),

                Spacer(),
              ],
            )
        ),

        Container(
          height: 60,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Container(
                    alignment: Alignment.bottomRight,
                    child: Text(
                      "Upcoming events",
                      style: TextStyle(
                          fontSize: 20,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.0
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10,top: 30),
                  child: Container(
                    alignment: Alignment.bottomRight,
                    child: FlatButton(
                      child: Text(
                        "Load More",
                        style: TextStyle(
                            color: Colors.blue[900]
                        ),
                      ),
                      onPressed: (){
                        Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => UpcomingEvent('Upcoming Events')),
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),

        GridView.builder(
          shrinkWrap: true,
          physics: ScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: (MediaQuery.of(context).size.width) / (MediaQuery.of(context).size.height/1.5),
          ),

          itemCount: _eventDetails.length > 6 ? 6 : _eventDetails.length , itemBuilder: (BuildContext context, int index) {
          return Card(
            margin: EdgeInsets.all(5.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8.0),
            ),
            elevation: 1.0,
            child: Container(
              child: FlatButton(
                onPressed: () {
                  setState(() {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => EventDescription(
                      title: "Lions International",
                      eventDate: _eventDetails[index].event.date,
                      eventTitle: _eventDetails[index].event.eventTitle,
                      eventDescription: _eventDetails[index].event.description,
                      eventImage: _eventDetails[index].image[0].img.replaceRange(0, 4, "https://lions3234d2.com"),
                    )));
                  });
                },

                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Builder(builder: (BuildContext context) {
                      return Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 5,top: 10,bottom: 5),
                          child: GestureDetector(
                            onTap: (){
                              Share.share(
                                  "*You are invited* on ${_eventDetails[index].event.date} for the following event");
                            },
                            child: Icon(
                              Icons.more_vert,
                              color: Colors.red,
                            ),
                          ),
                        ),
                      );
                    }),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 10.0,left: 10,right: 10),
                        child: Container(
                          height: 130,
                          width: 150,
                          child: Image.network(
                            _eventDetails[index].image[0].img.replaceRange(0, 4, "https://lions3234d2.com"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Text(
                      _eventDetails[index].event.eventTitle,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(
                      height: 3.0,
                    ),
                    Text(
                      _eventDetails[index].event.description,
                      textAlign: TextAlign.center,
                      maxLines: 2
                    ),
                    SizedBox(
                      height: 15.0,
                    )
                  ],
                ),
              ),
            ),
          );
        },
        ),


      ],
    );
  }

  @override
  void initState() {
    _getUpcomingEvents().then((value){
      setState(() {
        _eventDetails.addAll(value);
      });
    });
    
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: NavDrawer(),
      appBar: AppBar(
        elevation: 10,
        backgroundColor: mainColor,
        leading: GestureDetector(
          onTap: (){
            _scaffoldKey.currentState.openDrawer();
          },
          child: Icon(
            Icons.view_headline,
            size: 30,
          ),
        ),
        title: Text(
          widget.title,
          style: TextStyle(
              fontSize: 20
          ),
        ),
        actions: <Widget>[
          GestureDetector(
            onTap: (){
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfilePage('Profile')),
              );
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Icon(
                Icons.person,
                size: 28,
              ),
            ),
          )
        ],

      ),
      body: createBody(),
    );
  }
}

class HomePageThreeInRowCards extends StatelessWidget {
  HomePageThreeInRowCards({@required this.width, @required this.height, @required this.displayText, @required this.cardOnPressed, @required this.iconData,this.context});
  final double width;
  final double height;
  final String displayText;
  final IconData iconData;
  final dynamic cardOnPressed;

  final BuildContext context;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        cardOnPressed();
        },
      child: Container(
        width: width,
        height: height,
        child: Card(
          color: mainColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                iconData,
                color: Colors.white,
                size: 28.0,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(
                  child: Text(
                    displayText,
                    maxLines: 2,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        fontSize: 17
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

