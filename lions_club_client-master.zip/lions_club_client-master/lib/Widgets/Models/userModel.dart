class User{

  String memberId;
  String name;
  String email;
  String dob;
  String businessType;
  String clubId;
  String businessName;
  String address;
  String mobileNumber;
  String userName;
  String marriageDate;
  String type;

  User(
      this.memberId,
      this.name,
      this.email,
      this.dob,
      this.businessType,
      this.clubId,
      this.businessName,
      this.mobileNumber,
      this.address,
      this.userName,
      this.marriageDate,
      this.type,
      );

}