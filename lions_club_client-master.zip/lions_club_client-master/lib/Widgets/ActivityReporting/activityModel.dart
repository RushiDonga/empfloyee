class Activities{

  String  activityTitle;
  String  amount;
  String  city;
  String  date;
  String  cabinetOfficers;
  String  description;
  String  lionHours;
  String  mediaCoverage;
  String  peopleServed;
  dynamic  activityType;
  String  place;
  String  authorId;
  String  clubId;
 // dynamic  image;


  Activities(
  this.activityTitle,
  this.amount,
  this.city,
  this.date,
  this.cabinetOfficers,
  this.description,
  this.lionHours,
  this.mediaCoverage,
  this.peopleServed,
  this.activityType,
  this.place,
  this.authorId,
  this.clubId,
  //this.image,

      );

}