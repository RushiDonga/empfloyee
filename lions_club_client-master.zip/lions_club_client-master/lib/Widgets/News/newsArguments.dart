  
class NewsArguments{
  String newsTitles;
  String date;
  String imageUrls;
  String newsArticle;

  NewsArguments(this.newsTitles, this.date, this.imageUrls, this.newsArticle);
}