import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lionsclub/GetDetails/GetEvents.dart';
import 'package:share/share.dart';
import 'package:http/http.dart' as http;

class UpcomingEvent extends StatefulWidget {
  final String title;
  @override
  UpcomingEvent(this.title);
  _UpcomingEventState createState() => _UpcomingEventState();
}

class _UpcomingEventState extends State<UpcomingEvent> {


  List<GetEvents> _eventDetails = List<GetEvents>();

  Future<List<GetEvents>> _getUpcomingEvents() async {
    String url = "https://lions3234d2.com/api.php?category=events&view=true";
    var response = await http.get(url);
    var description = json.decode(response.body);
    List<GetEvents> events = [];

    if(response.statusCode == 200){
      for(var getEventJson in description){
        events.add(GetEvents.fromJson(getEventJson));
      }
    }
    return events;
  }

  createBody() {
    return ListView(
      children: <Widget>[
        GridView.builder(
          shrinkWrap: true,
          physics: ScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: (MediaQuery.of(context).size.width) / (MediaQuery.of(context).size.height/1.5),
          ),
          itemCount: _eventDetails.length, itemBuilder: (BuildContext context, int index) {
          return Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5.0),
            ),
            elevation: 2.0,
            child: Container(
              child: FlatButton(
                onPressed: (){
                  setState(() {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => EventDescription(
                        title: "Lions International",
                      eventDate: _eventDetails[index].event.date,
                      eventTitle: _eventDetails[index].event.eventTitle,
                      eventDescription: _eventDetails[index].event.description,
                      eventImage: _eventDetails[index].image[0].img.replaceRange(0, 4, "https://lions3234d2.com"),
                    )));
                  });

                },
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    Builder(builder: (BuildContext context) {
                      return Align(
                        alignment: Alignment.topRight,
                        child: Padding(
                          padding: const EdgeInsets.only(right: 5,top: 10,bottom: 5),
                          child: GestureDetector(
                            onTap: (){
                              Share.share(
                                  "*You are invited* on ${_eventDetails[index].event.date} for the following event");
                            },
                            child: Icon(
                              Icons.more_vert,
                              color: Colors.red,
                            ),
                          ),
                        ),
                      );
                    }),
                    Flexible(
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 10.0,left: 10,right: 10),
                        child: Container(
                          height: 130,
                          width: 150,
                          child: Image.network(
                            _eventDetails[index].image[0].img.replaceRange(0, 4, "https://lions3234d2.com"),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    Text(
                      _eventDetails[index].event.eventTitle,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    Text(
                      _eventDetails[index].event.description,
                      textAlign: TextAlign.center,
                      maxLines: 2,
                    ),
                    SizedBox(
                      height: 15.0,
                    )
                  ],
                ),
              ),
            ),
          );
        },
        ),
      ],
    );
  }

  @override
  void initState() {
    _getUpcomingEvents().then((value){
      setState(() {
        _eventDetails.addAll(value);
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
        ),
        body: createBody(),
      ),
    );
  }
}















// Another Activity Goes Here
class EventDescription extends StatefulWidget {
  _EventDescriptionState createState() => _EventDescriptionState();

  EventDescription({@required this.title, @required this.eventTitle, @required this.eventDate, @required this.eventDescription, @required this.eventImage});
  final String title;
  final String eventTitle;
  final String eventDate;
  final String eventDescription;
  final String eventImage;
}

class _EventDescriptionState extends State<EventDescription> {
  share(BuildContext context) {}

  Widget createDescription() {
    return Stack(
      children: [
        ListView(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.network(
                widget.eventImage,
                height: 150,
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Text(
                    widget.eventTitle,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                      fontSize: 21.0,
                      color: Colors.grey[800]
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 8.0, right: 8.0),
                  child: Row(
                    children: <Widget>[
                      Padding(
                        padding: const EdgeInsets.only(left: 12.0),
                        child: Icon(
                          Icons.calendar_today,
                          color: Colors.red,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 12.0),
                        child: Text(
                            widget.eventDate,
                          style: TextStyle (
                            color: Colors.grey[900],
                            fontSize: 17.0
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
                  child: Text(
                    widget.eventDescription,
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 16.0
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 70.0,
            width: MediaQuery.of(context).size.width,
            color: Colors.white,
            child: Container(
              color: Colors.white,
              margin: EdgeInsets.symmetric(vertical: 16.0, horizontal: 120.0),
              child: RaisedButton(
                color: Colors.red,
                textColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8.0))
                ),
                child: Text(
                  'GET TICKET',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 15.0,
                  ),
                ),
                onPressed: () {
                  // on Pressed Goes here
                },
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: createDescription(),
    );
  }
}
