class AdminReportApi {

  String reporting;
  String perMonthOne;
  String gradeOne;

  String meetings;
  String perMonthTwo;
  String gradeTwo;

  String finance;
  String perMonthThree;
  String gradeThree;

  String visit;
  String perMonthFour;
  String gradeFour;

  String publication;
  String perMonthFive;
  String gradeFive;

  String membership;
  String perMonthSix;
  String gradeSix;

  String lcif;
  String perMonthSeven;
  String gradeSeven;

  String participation;
  String perMonthEight;
  String gradeEight;

  AdminReportApi(this.reporting,
      this.perMonthOne,
      this.gradeOne,
      this.meetings,
      this.perMonthTwo,
      this.gradeTwo,
      this.finance,
      this.perMonthThree,
      this.gradeThree,
      this.visit,
      this.perMonthFour,
      this.gradeFour,
      this.publication,
      this.perMonthFive,
      this.gradeFive,
      this.membership,
      this.perMonthSix,
      this.gradeSix,
      this.participation,
      this.perMonthSeven,
      this.gradeSeven,
      this.lcif,
      this.perMonthEight,
      this.gradeEight
      //this.image,
      );
}