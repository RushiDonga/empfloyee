import 'package:lionsclub/Widgets/Billing/uploadBills.dart';

class UploadBillsApi{

  String  venue;
  String  amount;
  String  selectDate;
  dynamic selectFile;
  dynamic uploadImage;

  UploadBillsApi(
      this.venue,
      this.amount,
      this.selectDate,
      this.selectFile,
      this.uploadImage,

      );

}