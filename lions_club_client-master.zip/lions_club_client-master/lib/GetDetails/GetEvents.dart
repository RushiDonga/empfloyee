class GetEvents {
  Event event;
  List<EventImage> image;

  GetEvents({this.event, this.image});

  GetEvents.fromJson(Map<String, dynamic> json) {
    event = json['event'] != null ? new Event.fromJson(json['event']) : null;
    if (json['image'] != null) {
      image = new List<EventImage>();
      json['image'].forEach((v) {
        image.add(new EventImage.fromJson(v));
      });
    }
  }
}

class Event {
  String eventId;
  String eventTitle;
  String amount;
  String chiefGuest;
  String date;
  String district;
  String description;
  String eventType;
  String authorId;
  String clubId;

  Event(
      {this.eventId,
        this.eventTitle,
        this.amount,
        this.chiefGuest,
        this.date,
        this.district,
        this.description,
        this.eventType,
        this.authorId,
        this.clubId});

  Event.fromJson(Map<String, dynamic> json) {
    eventId = json['eventId'];
    eventTitle = json['eventTitle'];
    amount = json['amount'];
    chiefGuest = json['chiefGuest'];
    date = json['date'];
    district = json['district'];
    description = json['description'];
    eventType = json['eventType'];
    authorId = json['authorId'];
    clubId = json['clubId'];
  }
}

class EventImage {
  String img;

  EventImage({this.img});

  EventImage.fromJson(Map<String, dynamic> json) {
    img = json['img'];
  }
}
