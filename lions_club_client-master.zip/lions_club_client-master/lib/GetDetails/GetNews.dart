class GetNews {
  EventNews event;
  List<EventNewsImage> image;

  GetNews({this.event, this.image});

  GetNews.fromJson(Map<String, dynamic> json) {
    event = json['news'] != null ? new EventNews.fromJson(json['news']) : null;
    if (json['image'] != null) {
      image = new List<EventNewsImage>();
      json['image'].forEach((v) {
        image.add(new EventNewsImage.fromJson(v));
      });
    }
  }
}

class EventNews {
  String newsId;
  String newsTitle;
  String date;
  String description;
  String newsPaperLink;
  String authorId;
  String clubId;
  String verified;

  EventNews(
      {this.newsId,
        this.newsTitle,
        this.date,
        this.description,
        this.newsPaperLink,
        this.authorId,
        this.clubId,
        this.verified,
      });

  EventNews.fromJson(Map<String, dynamic> json) {
    newsId = json['newsId'];
    newsTitle = json['newsTitle'];
    date = json['date'];
    description = json['description'];
    newsPaperLink = json['newsPaperLink'];
    authorId = json['authorId'];
    description = json['description'];
    clubId = json['clubId'];
    verified = json['verified'];
  }
}

class EventNewsImage {
  String img;
  EventNewsImage({this.img});
  EventNewsImage.fromJson(Map<String, dynamic> json) {
    img = json['img'];
  }
}
