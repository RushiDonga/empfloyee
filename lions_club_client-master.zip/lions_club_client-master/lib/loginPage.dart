import 'package:flutter/material.dart';
import 'homePage.dart';
import 'package:flutter/services.dart';
import 'Animation/animation.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'package:toast/toast.dart';

class LoginPage extends StatefulWidget {
  final String title;

  @override
  LoginPage(this.title);
  _LoginPageState createState() => _LoginPageState();
}



Color mainColor = Colors.red;
Color blackColor = Colors.black;
Color whiteColor = Colors.white;

class _LoginPageState extends State<LoginPage> {

  String _userName;
  String _password;

  // Check if the Fields are Empty
  _checkFields(){
    _userName == null && _password == null
        ? Toast.show("Invalid Credentials", context, duration: Toast.LENGTH_LONG, gravity: Toast.CENTER)
        : _checkCredentials();
  }

  // Check for the Valid Credentials
  _checkCredentials() async{
    String url = "https://lions3234d2.com/api.php";
    http.Response response = await http.post(
        url,
      body: {
          "login":"true",
        "id": _userName,
        "password": _password,
      }
    );

    if(response.statusCode == 200){
      if(jsonDecode(response.body)['error'] == 'success'){
        _navigateToLogin(context);
      }else{
        Toast.show("Invalid Credentials", context, duration: Toast.LENGTH_LONG, gravity: Toast.CENTER);
      }
    }
  }

  void _navigateToLogin(BuildContext context){
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => MyHomePage(widget.title)),
    );
  }

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget createBody() {
    return SafeArea(
      child: Container(
        color: mainColor,
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                FadeAnimation(
                    1.2,
                    "LX",
                    Container(
                      height: 330,
                      decoration: BoxDecoration(
                        color: blackColor,
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(00),
                            bottomRight: Radius.elliptical(400, 250)),
                      ),
                    )),
                Container(
                  height: 300,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(000),
                        bottomRight: Radius.elliptical(400, 250)),
                  ),
                ),
                Positioned(
                    left: 10,
                    bottom: 60,
                    child: FadeAnimation(
                        2,
                        "LX",
                        Container(
                          width: 150,
                          height: 150,
                          child: Image.asset('images/logo.png'),
                        ))),
                Positioned(
                  left: 20,
                  top: 70,
                  right: 20,
                  child: FadeAnimation(
                    1,
                    "LX",
                    Container(
                      child: Text(
                        "Lion's International",
                        maxLines: 1,
                        style: TextStyle(
                            fontSize: 30,
                            color: mainColor,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Spacer(
              flex: 2,
            ),

            FadeAnimation(
              1.3,
              "LY",
              Padding(
                padding: const EdgeInsets.only(left: 50, right: 50, top: 10),
                child: GestureDetector(
                  onTap: () {
                    //       return _navigateToLogin(context);
                  },
                  child: Container(
                    alignment: Alignment.bottomLeft,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: TextField(
                          cursorWidth: 2,
                          obscureText: false,
                          maxLengthEnforced: false,
                          cursorColor: blackColor,
                          onChanged: (value){
                            setState(() {
                              _userName = value;
                            });
                          },
                          decoration: InputDecoration(
                            helperMaxLines: 0,
                            border: InputBorder.none,
                            hintText: "Username",
                            hintStyle: TextStyle(
                              fontSize: 20,
                            ),
                          ),
                        ),
                      ),
                    ),
                    height: 50,
                  ),
                ),
              ),
            ),

            SizedBox(
              height: 10,
            ),

//          9720520514

            FadeAnimation(
              1.5,
              "RY",
              Padding(
                padding: const EdgeInsets.only(left: 50, right: 50, top: 10),
                child: GestureDetector(
                  onTap: () {
                    //     return _navigateToLogin(context);
                  },
                  child: Container(
                    alignment: Alignment.bottomLeft,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: TextField(
                          cursorWidth: 2,
                          obscureText: true,
                          maxLengthEnforced: false,
                          cursorColor: blackColor,
                          onChanged: (value){
                            setState(() {
                              _password = value;
                            });
                          },
                          decoration: InputDecoration(
                            helperMaxLines: 0,
                            border: InputBorder.none,
                            hintText: "Password",
                            hintStyle: TextStyle(
                              fontSize: 20,
                            ),
                          ),
                        ),
                      ),
                    ),
                    height: 50,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 50,
            ),
            FadeAnimation(
              1.7,
              'RX',
              Padding(
                padding: const EdgeInsets.only(left: 40, right: 40, top: 10),
                child: GestureDetector(
                  onTap: () {
                    _checkFields();
                    //return _navigateToLogin(context);
                  },
                  child: Container(
                    alignment: Alignment.bottomLeft,
                    decoration: BoxDecoration(
                      color: blackColor,
                      borderRadius: BorderRadius.circular(400),
                    ),
                    child: Center(
                      child: Text(
                        "Login",
                        style: TextStyle(
                          fontSize: 20,
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    height: 60,
                  ),
                ),
              ),
            ),
            Spacer(
              flex: 1,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomPadding: false,

        body: createBody());
  }
}
