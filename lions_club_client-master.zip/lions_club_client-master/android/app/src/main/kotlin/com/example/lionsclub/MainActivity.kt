package com.example.lionsclub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
